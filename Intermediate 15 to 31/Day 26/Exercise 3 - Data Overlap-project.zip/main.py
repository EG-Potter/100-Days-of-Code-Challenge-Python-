with open("file1.txt") as f:
    file1_List = [int(x) for x in f.read().split()]
with open("file2.txt") as f:
    file2_List = [int(x) for x in f.read().split()]

result = [x for x in  file1_List if x in file2_List]

# Write your code above 👆

print(result)


